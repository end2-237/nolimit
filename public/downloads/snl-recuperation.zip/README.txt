═══════════════════════════════════════════════════════
  SNL — Outil de Récupération IndexedDB
  Version standalone — fonctionne sur n'importe quel PC
═══════════════════════════════════════════════════════

CONTENU DU DOSSIER
──────────────────
  lancer.bat          <- double-cliquer pour démarrer
  electron-main.cjs   <- lanceur Electron (mode RECOMMANDÉ)
  serveur.cjs         <- serveur HTTP Node.js (mode navigateur)
  recuperer.html      <- interface de récupération
  README.txt          <- ce fichier

UTILISATION
───────────

-> Double-cliquer sur lancer.bat

Le script te propose deux modes :

  [1] Mode ELECTRON (RECOMMANDÉ)
      -> Ouvre le dashboard DANS Electron en pointant directement
         vers les données de l'app SNL installée
      -> Données dans %APPDATA%\No Limit Stock\IndexedDB\...
      -> Fonctionne même si l'app ne s'ouvre plus

  [2] Mode NAVIGATEUR
      -> Sert le dashboard via Node.js, ouvre dans Chrome/Edge
      -> Ne voit QUE les données ouvertes via le navigateur
      -> NE VOIT PAS les données de l'app Electron installée

POURQUOI MODE ELECTRON ?
────────────────────────
  IndexedDB est isolé par origine ET par contexte (Electron ≠ Chrome).
  Les données de l'app SNL installée sont stockées dans le profil
  Chromium interne d'Electron, inaccessibles depuis Chrome ou Edge.

  Mode Electron = même moteur Chromium, même userData
               = accès direct aux vraies données.

PRÉREQUIS
─────────
  • Windows 10/11
  • Node.js installé (https://nodejs.org) pour les deux modes
  • Mode Electron : le projet SNL doit être présent sur le PC
    (cherche dans D:\SNL\node_modules\electron\dist\electron.exe)

NODE.JS NON INSTALLÉ ?
──────────────────────
  Télécharge Node.js LTS sur https://nodejs.org

APRÈS L'EXPORT
──────────────
  Le fichier snl-recovery-YYYY-MM-DD.json est sauvegardé
  dans ton dossier Téléchargements.

  Pour réimporter dans l'app :
  -> Paramètres -> Importer une sauvegarde -> sélectionner le .json

SÉCURITÉ
────────
  Cet outil est 100% lecture seule.
  Il ne modifie ni ne supprime aucune donnée.
  Toutes les transactions IndexedDB sont en mode 'readonly'.
  Le localStorage est copié uniquement via getItem().

═══════════════════════════════════════════════════════
