/**
 * serveur.cjs — SNL Diagnostic Center : serveur Node.js
 * Sert le dashboard sur localhost:PORT, gère sauvegarde + diagnostics système.
 */

const http     = require('http');
const fs       = require('fs');
const path     = require('path');
const os       = require('os');
const { exec, execSync, spawn } = require('child_process');

const PORT     = parseInt(process.argv[2] || '5173', 10);
const APP_NAME = process.argv[3] || 'No Limit Stock';
const HTML     = path.join(__dirname, 'recuperer.html');
const SAVE_DIR = path.join(os.homedir(), 'Downloads');
const USERDATA = path.join(os.homedir(), 'AppData', 'Roaming', APP_NAME);

function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', c => { body += c; if (body.length > 50 * 1024 * 1024) reject(new Error('Payload trop grand')); });
    req.on('end', () => resolve(body));
    req.on('error', reject);
  });
}

function tryExecSync(cmd) {
  // stdio: pipe capture stderr → ne pollue plus le terminal avec les erreurs PS
  try { return execSync(cmd, { encoding: 'utf8', timeout: 6000, shell: true, windowsHide: true, stdio: ['pipe','pipe','pipe'] }); }
  catch { return ''; }
}

// Écrit un script PS1 dans un fichier temp, l'exécute, puis efface le fichier.
// Evite tout problème d'échappement des guillemets dans -Command "...".
function runPs1(scriptContent) {
  const tmp = path.join(os.tmpdir(), `snl-ps-${process.pid}-${Date.now()}.ps1`);
  try {
    fs.writeFileSync(tmp, scriptContent, 'utf8');
    return tryExecSync(`powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "${tmp}"`);
  } finally {
    try { fs.unlinkSync(tmp); } catch {}
  }
}

function folderSizeMB(folderPath) {
  try {
    const out = tryExecSync(`powershell -NoProfile -Command "(Get-ChildItem -Recurse -Force '${folderPath.replace(/'/g, "''")}' -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum"`);
    const bytes = parseInt(out.trim(), 10);
    if (isNaN(bytes)) return null;
    return Math.round(bytes / 1024 / 1024);
  } catch { return null; }
}

// ── Trouver l'exécutable de l'app SNL installée ──────────────────────────────
// Cherche uniquement l'app packagée installée sur le PC (pas le projet dev).
// Ordre : chemins filesystem directs → Squirrel → Registre (PS1 temp) → Start Menu (PS1 temp)
function findInstalledSnlExe(appName) {
  const local   = process.env.LOCALAPPDATA || path.join(os.homedir(), 'AppData', 'Local');
  const roaming = process.env.APPDATA      || path.join(os.homedir(), 'AppData', 'Roaming');
  const pf64    = process.env['ProgramFiles']      || 'C:\\Program Files';
  const pf32    = process.env['ProgramFiles(x86)'] || 'C:\\Program Files (x86)';

  // 1. Chemins filesystem directs — NSIS, Squirrel root stub, Program Files
  const direct = [
    path.join(local,   'Programs', appName, `${appName}.exe`),
    path.join(local,   'Programs', appName, 'app.exe'),
    path.join(local,   appName,    `${appName}.exe`),  // stub Squirrel à la racine
    path.join(pf64,    appName,    `${appName}.exe`),
    path.join(pf32,    appName,    `${appName}.exe`),
    path.join(roaming, appName,    `${appName}.exe`),
  ];
  for (const p of direct) {
    if (fs.existsSync(p)) return p;
  }

  // 1b. App Paths registry — clé dédiée aux exe, cherchée par Windows lui-même
  for (const hive of ['HKCU', 'HKLM']) {
    const regOut = tryExecSync(
      `reg query "${hive}\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\App Paths\\${appName}.exe" /ve`
    );
    if (regOut && regOut.trim()) {
      const m = regOut.match(/REG_SZ\s+(.+\.exe)/i);
      if (m) {
        const p = m[1].trim();
        if (fs.existsSync(p)) return p;
      }
    }
  }

  // 2. Squirrel.Windows — %LOCALAPPDATA%\{AppName}\app-X.Y.Z\{AppName}.exe
  const squirrelBase = path.join(local, appName);
  if (fs.existsSync(squirrelBase)) {
    try {
      const isAppExe = f =>
        f.endsWith('.exe') &&
        !f.toLowerCase().includes('uninstall') &&
        !f.toLowerCase().includes('update') &&
        !f.toLowerCase().startsWith('squirrel');

      // Dossiers versionnés app-X.Y.Z
      const versions = fs.readdirSync(squirrelBase)
        .filter(e => e.startsWith('app-'))
        .sort().reverse();
      for (const v of versions) {
        const vDir = path.join(squirrelBase, v);
        // Exact match
        const exact = path.join(vDir, `${appName}.exe`);
        if (fs.existsSync(exact)) return exact;
        // N'importe quel exe dans ce dossier
        const exes = fs.readdirSync(vDir).filter(isAppExe);
        if (exes.length === 1) return path.join(vDir, exes[0]);
        const best = exes.find(f => f.toLowerCase().includes(appName.toLowerCase().split(' ')[0]));
        if (best) return path.join(vDir, best);
      }

      // Exe à la racine du dossier Squirrel (stub ou app sans version)
      const rootExes = fs.readdirSync(squirrelBase).filter(isAppExe);
      if (rootExes.length === 1) return path.join(squirrelBase, rootExes[0]);
      const rootBest = rootExes.find(f => f.toLowerCase().includes(appName.toLowerCase().split(' ')[0]));
      if (rootBest) return path.join(squirrelBase, rootBest);
    } catch {}
  }

  // 3. Registre Windows via fichier PS1 temporaire
  //    Guillemets simples PS pour éviter tout pb d'échappement
  try {
    const safe = appName.replace(/'/g, "''");
    const ps3 = [
      `$keys = @(`,
      `  'HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall',`,
      `  'HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall',`,
      `  'HKLM:\\SOFTWARE\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall'`,
      `)`,
      `foreach ($key in $keys) {`,
      `  if (!(Test-Path $key)) { continue }`,
      `  Get-ChildItem $key -ErrorAction SilentlyContinue | ForEach-Object {`,
      `    $p = Get-ItemProperty $_.PSPath -ErrorAction SilentlyContinue`,
      `    if ($p.DisplayName -and $p.DisplayName -like '*${safe}*') {`,
      `      if ($p.InstallLocation) { Write-Output ('LOC:' + $p.InstallLocation) }`,
      `      if ($p.DisplayIcon)     { Write-Output ('ICO:' + $p.DisplayIcon) }`,
      `    }`,
      `  }`,
      `}`,
    ].join('\r\n');
    const out = runPs1(ps3);
    if (out && out.trim()) {
      for (const line of out.trim().split('\n')) {
        const l = line.trim();
        if (l.startsWith('LOC:')) {
          const loc = l.slice(4).trim().replace(/^["']|["']$/g, '');
          if (!loc) continue;
          const exeInLoc = path.join(loc, `${appName}.exe`);
          if (fs.existsSync(exeInLoc)) return exeInLoc;
          try {
            const files = fs.readdirSync(loc).filter(f =>
              f.endsWith('.exe') &&
              !f.toLowerCase().includes('uninstall') &&
              !f.toLowerCase().includes('update')
            );
            if (files.length === 1) return path.join(loc, files[0]);
            const match = files.find(f =>
              f.toLowerCase().includes(appName.toLowerCase().split(' ')[0])
            );
            if (match) return path.join(loc, match);
          } catch {}
        }
        if (l.startsWith('ICO:')) {
          const ico = l.slice(4).trim().replace(/^["']|["']$/g, '').split(',')[0];
          if (ico && ico.endsWith('.exe') && fs.existsSync(ico)) return ico;
        }
      }
    }
  } catch {}

  // 4. Raccourcis Start Menu via fichier PS1 temporaire
  try {
    const safe = appName.replace(/'/g, "''");
    const startMenus = [
      path.join(roaming, 'Microsoft', 'Windows', 'Start Menu', 'Programs'),
      path.join(local,   'Microsoft', 'Windows', 'Start Menu', 'Programs'),
      'C:\\ProgramData\\Microsoft\\Windows\\Start Menu\\Programs',
    ];
    const ps4 = [
      `$name = '${safe}'`,
      `$dirs = @(`,
      ...startMenus.map((d, i, a) =>
        `  '${d.replace(/'/g, "''")}' ${i < a.length - 1 ? ',' : ''}`
      ),
      `)`,
      `foreach ($d in $dirs) {`,
      `  if (!(Test-Path $d)) { continue }`,
      `  Get-ChildItem -Recurse $d -Filter '*.lnk' -ErrorAction SilentlyContinue |`,
      `  Where-Object { $_.Name -like "*$name*" } |`,
      `  ForEach-Object {`,
      `    try {`,
      `      $sh = New-Object -ComObject WScript.Shell`,
      `      $t  = $sh.CreateShortcut($_.FullName).TargetPath`,
      `      if ($t -and $t.EndsWith('.exe') -and (Test-Path $t)) { Write-Output $t }`,
      `    } catch {}`,
      `  }`,
      `}`,
    ].join('\r\n');
    const lnkOut = runPs1(ps4);
    if (lnkOut && lnkOut.trim()) {
      const first = lnkOut.trim().split('\n')[0].trim();
      if (first && fs.existsSync(first)) return first;
    }
  } catch {}

  return null; // introuvable
}

function getDiagnostics(appName) {
  const ud = path.join(os.homedir(), 'AppData', 'Roaming', appName);
  const result = {
    ok: true,
    appName,
    userData: ud,
    userDataExists: fs.existsSync(ud),
    locks: [],
    snlProcesses: [],
    port5173: { busy: false, pid: null },
    cacheFolders: [],
    logLines: [],
    logFile: null,
    indexeddbPath: null,
    appExe: findInstalledSnlExe(appName),
  };

  // ── Fichiers verrou ──────────────────────────────────────────────────────
  const lockCandidates = [
    { rel: 'SingletonLock',                    label: 'SingletonLock' },
    { rel: 'SingletonSocket',                  label: 'SingletonSocket' },
    { rel: path.join('Default', 'LOCK'),       label: 'Default/LOCK (IndexedDB)' },
  ];
  for (const lc of lockCandidates) {
    const fp = path.join(ud, lc.rel);
    if (fs.existsSync(fp)) result.locks.push({ file: lc.rel, label: lc.label, fullPath: fp });
  }

  // ── Processus Electron actifs ────────────────────────────────────────────
  const plist = tryExecSync('tasklist /FI "IMAGENAME eq electron.exe" /NH /FO CSV');
  if (plist) {
    const lines = plist.split('\n').filter(l => l.toLowerCase().includes('electron.exe'));
    lines.forEach(line => {
      const parts = line.split('","');
      if (parts.length >= 5) {
        const pid = parts[1]?.replace(/"/g, '').trim();
        const mem = parts[4]?.replace(/"/g, '').trim();
        if (pid && !isNaN(parseInt(pid))) result.snlProcesses.push({ pid: parseInt(pid), mem: mem || '?' });
      }
    });
  }

  // ── Port 5173 ────────────────────────────────────────────────────────────
  const nsOut = tryExecSync('netstat -ano 2>nul | findstr ":5173 " | findstr "LISTENING"');
  if (nsOut && nsOut.trim()) {
    result.port5173.busy = true;
    const parts = nsOut.trim().split(/\s+/);
    const pid = parseInt(parts[parts.length - 1]);
    if (!isNaN(pid)) result.port5173.pid = pid;
  }

  // ── Dossiers cache ───────────────────────────────────────────────────────
  const cacheDirs = ['GPUCache', 'ShaderCache', 'Code Cache', 'CrashPad', 'DawnCache'];
  for (const cd of cacheDirs) {
    const cp = path.join(ud, cd);
    if (fs.existsSync(cp)) {
      const sizeMB = folderSizeMB(cp);
      result.cacheFolders.push({ name: cd, fullPath: cp, sizeMB });
    }
  }

  // ── Chemin IndexedDB ──────────────────────────────────────────────────────
  const idbBase = path.join(ud, 'Default', 'IndexedDB');
  if (fs.existsSync(idbBase)) result.indexeddbPath = idbBase;

  // ── Derniers logs app ─────────────────────────────────────────────────────
  const logsDir = path.join(ud, 'logs');
  if (fs.existsSync(logsDir)) {
    try {
      const files = fs.readdirSync(logsDir)
        .filter(f => f.endsWith('.log') || f.endsWith('.txt'))
        .map(f => ({ f, mtime: fs.statSync(path.join(logsDir, f)).mtimeMs }))
        .sort((a, b) => b.mtime - a.mtime);
      if (files.length) {
        const raw = fs.readFileSync(path.join(logsDir, files[0].f), 'utf8');
        result.logLines = raw.split('\n').filter(Boolean).slice(-40);
        result.logFile = files[0].f;
      }
    } catch {}
  }

  return result;
}

const server = http.createServer(async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') { res.writeHead(204); res.end(); return; }

  // ── GET / → dashboard HTML ───────────────────────────────────────────────
  if (req.method === 'GET' && (req.url === '/' || req.url.startsWith('/?'))) {
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.setHeader('Cache-Control', 'no-store');
    try { res.end(fs.readFileSync(HTML)); }
    catch { res.writeHead(500); res.end('recuperer.html introuvable'); }
    return;
  }

  // ── POST /save → écrire JSON sur disque ─────────────────────────────────
  if (req.method === 'POST' && req.url === '/save') {
    try {
      const body = await readBody(req);
      const { filename, content } = JSON.parse(body);
      const safe = (filename || `snl-recovery-${Date.now()}.json`).replace(/[/\\:*?"<>|]/g, '-');
      const dest = path.join(SAVE_DIR, safe);
      fs.writeFileSync(dest, content, 'utf8');
      res.setHeader('Content-Type', 'application/json');
      res.end(JSON.stringify({ ok: true, path: dest, size: content.length }));
      console.log(`  [SAVE] ${dest} (${(content.length / 1024).toFixed(1)} KB)`);
    } catch (e) {
      res.writeHead(500);
      res.end(JSON.stringify({ ok: false, error: e.message }));
    }
    return;
  }

  // ── GET /ping → health check ─────────────────────────────────────────────
  if (req.method === 'GET' && req.url === '/ping') {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify({ ok: true, mode: 'node', port: PORT, pid: process.pid, appName: APP_NAME, userData: USERDATA }));
    return;
  }

  // ── GET /diag → diagnostic système ──────────────────────────────────────
  if (req.method === 'GET' && req.url.startsWith('/diag') && !req.url.startsWith('/diag/')) {
    try {
      const urlParsed = new URL(req.url, `http://localhost:${PORT}`);
      const appName = urlParsed.searchParams.get('appName') || APP_NAME;
      const diag = getDiagnostics(appName);
      res.setHeader('Content-Type', 'application/json');
      res.end(JSON.stringify(diag));
    } catch (e) {
      res.writeHead(500);
      res.end(JSON.stringify({ ok: false, error: e.message }));
    }
    return;
  }

  // ── POST /diag/fix → appliquer une correction ────────────────────────────
  if (req.method === 'POST' && req.url === '/diag/fix') {
    try {
      const body = await readBody(req);
      const { action, appName = APP_NAME, exePath } = JSON.parse(body);
      const ud = path.join(os.homedir(), 'AppData', 'Roaming', appName);
      let message = '';
      let ok = true;
      let details = [];

      if (action === 'remove_singleton') {
        const targets = [
          path.join(ud, 'SingletonLock'),
          path.join(ud, 'SingletonSocket'),
          path.join(ud, 'Default', 'LOCK'),
        ];
        let removed = 0;
        for (const t of targets) {
          if (fs.existsSync(t)) {
            try { fs.unlinkSync(t); removed++; details.push(`Supprime : ${path.basename(t)}`); }
            catch (e2) { details.push(`Erreur sur ${path.basename(t)} : ${e2.message}`); ok = false; }
          }
        }
        message = removed > 0 ? `${removed} fichier(s) verrou supprime(s).` : 'Aucun fichier verrou trouve.';

      } else if (action === 'kill_snl') {
        const before = tryExecSync('tasklist /FI "IMAGENAME eq electron.exe" /NH /FO CSV');
        const count = (before.match(/electron\.exe/gi) || []).length;
        if (count === 0) {
          message = 'Aucun processus Electron en cours d\'execution.';
        } else {
          tryExecSync('taskkill /F /IM electron.exe 2>nul');
          message = `${count} processus Electron termine(s).`;
        }

      } else if (action === 'clear_gpu') {
        const p = path.join(ud, 'GPUCache');
        if (fs.existsSync(p)) { fs.rmSync(p, { recursive: true, force: true }); message = 'GPUCache supprime.'; }
        else { message = 'GPUCache introuvable (deja absent).'; }

      } else if (action === 'clear_shader') {
        const p = path.join(ud, 'ShaderCache');
        if (fs.existsSync(p)) { fs.rmSync(p, { recursive: true, force: true }); message = 'ShaderCache supprime.'; }
        else { message = 'ShaderCache introuvable.'; }

      } else if (action === 'clear_code_cache') {
        const p = path.join(ud, 'Code Cache');
        if (fs.existsSync(p)) { fs.rmSync(p, { recursive: true, force: true }); message = 'Code Cache supprime.'; }
        else { message = 'Code Cache introuvable.'; }

      } else if (action === 'clear_crash') {
        const p = path.join(ud, 'CrashPad');
        if (fs.existsSync(p)) { fs.rmSync(p, { recursive: true, force: true }); message = 'CrashPad supprime.'; }
        else { message = 'CrashPad introuvable.'; }

      } else if (action === 'launch_app') {
        // Supprimer les verrous (pas de taskkill : tuerait l'outil de récupération lui-même)
        const locks = [
          path.join(ud, 'SingletonLock'),
          path.join(ud, 'SingletonSocket'),
          path.join(ud, 'Default', 'LOCK'),
        ];
        for (const l of locks) { if (fs.existsSync(l)) { try { fs.unlinkSync(l); } catch {} } }
        // 3. Trouver et lancer l'app installée
        const found = findInstalledSnlExe(appName);
        let launched = false;
        if (!found) {
          // Nettoyage fait, mais exe pas trouvé
          message = `Verrous et processus nettoyés. Exécutable introuvable — lance l'app manuellement.`;
          details = ['Processus Electron terminés', 'Verrous supprimés', 'Exe introuvable : lance manuellement'];
          ok = true;
        } else {
          launched = true;
          setTimeout(() => {
            try { spawn(found, [], { detached: true, stdio: 'ignore' }).unref(); } catch {}
          }, 800);
          message = found;
          details = ['Processus bloquants terminés', 'Verrous supprimés', `Lancement : ${found}`];
        }
        // Inclure launched + appExe dans la réponse pour le frontend
        res.setHeader('Content-Type', 'application/json');
        res.end(JSON.stringify({ ok, launched, appExe: found || null, message, details }));
        console.log(`  [FIX] ${action} -> launched=${launched} ${message}`);
        return;

      } else if (action === 'launch_manual') {
        // Lancement avec chemin fourni manuellement par l'utilisateur
        if (!exePath || typeof exePath !== 'string') {
          ok = false; message = 'Chemin exe manquant.';
        } else {
          // Supprimer les verrous (pas de taskkill : tuerait l'outil de récupération)
          const locks = [
            path.join(ud, 'SingletonLock'),
            path.join(ud, 'SingletonSocket'),
            path.join(ud, 'Default', 'LOCK'),
          ];
          for (const l of locks) { if (fs.existsSync(l)) { try { fs.unlinkSync(l); } catch {} } }
          // Vérifier que l'exe existe
          if (!fs.existsSync(exePath)) {
            ok = false; message = `Fichier introuvable : ${exePath}`;
          } else {
            setTimeout(() => {
              try { spawn(exePath, [], { detached: true, stdio: 'ignore' }).unref(); } catch {}
            }, 800);
            message = exePath;
            details = ['Verrous supprimés', `Lancement : ${exePath}`];
            res.setHeader('Content-Type', 'application/json');
            res.end(JSON.stringify({ ok: true, launched: true, message, details }));
            console.log(`  [FIX] launch_manual -> ${exePath}`);
            return;
          }
        }

      } else if (action === 'auto_repair') {
        const steps = [];
        const locks = [
          path.join(ud, 'SingletonLock'),
          path.join(ud, 'SingletonSocket'),
          path.join(ud, 'Default', 'LOCK'),
        ];
        let lr = 0;
        for (const l of locks) { if (fs.existsSync(l)) { try { fs.unlinkSync(l); lr++; } catch {} } }
        if (lr > 0) steps.push(`${lr} verrou(s) supprimes`);
        const caches = ['GPUCache', 'ShaderCache', 'CrashPad', 'DawnCache'];
        let cr = 0;
        for (const c of caches) {
          const cp = path.join(ud, c);
          if (fs.existsSync(cp)) { try { fs.rmSync(cp, { recursive: true, force: true }); cr++; } catch {} }
        }
        if (cr > 0) steps.push(`${cr} dossier(s) cache vides`);
        message = steps.join(' · ') || 'Aucune action necessaire.';
        details = steps;

      } else {
        ok = false;
        message = `Action inconnue : "${action}"`;
      }

      console.log(`  [FIX] ${action} -> ${message}`);
      res.setHeader('Content-Type', 'application/json');
      res.end(JSON.stringify({ ok, message, details }));
    } catch (e) {
      res.writeHead(500);
      res.end(JSON.stringify({ ok: false, error: e.message }));
    }
    return;
  }

  // ── POST /stop → arrêter le serveur ─────────────────────────────────────
  if (req.method === 'POST' && req.url === '/stop') {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify({ ok: true }));
    console.log('\n  Arret demande. Fermeture...');
    setTimeout(() => process.exit(0), 200);
    return;
  }

  res.writeHead(404);
  res.end('Not found');
});

server.on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.error(`\n  ERREUR : port ${PORT} deja occupe.`);
    console.error(`  Ferme l'app SNL puis relance lancer.bat.\n`);
  } else {
    console.error('  Erreur serveur :', err.message);
  }
  process.exit(1);
});

server.listen(PORT, '127.0.0.1', () => {
  const url = `http://localhost:${PORT}`;
  console.log('');
  console.log('  ====================================================');
  console.log('    SNL Diagnostic Center');
  console.log('  ====================================================');
  console.log(`  URL      : ${url}`);
  console.log(`  App      : ${APP_NAME}`);
  console.log(`  userData : ${USERDATA}`);
  console.log(`  PID      : ${process.pid}`);
  console.log('  ====================================================');
  console.log('  Ctrl+C pour arreter');
  console.log('');

  const cmd = process.platform === 'win32'
    ? `start "" "${url}"`
    : process.platform === 'darwin' ? `open "${url}"` : `xdg-open "${url}"`;
  exec(cmd);
});

process.on('SIGINT', () => { console.log('\n  Serveur arrete.'); process.exit(0); });
