@echo off
title SNL - Recovery Dashboard
setlocal EnableDelayedExpansion

echo.
echo  SNL - Recovery Dashboard
echo  ========================
echo.

:: ─────────────────────────────────────────────────────────────────────────────
::  Detecter Electron
:: ─────────────────────────────────────────────────────────────────────────────
set ELECTRON_EXE=
if exist "D:\SNL\node_modules\electron\dist\electron.exe" (
    set ELECTRON_EXE=D:\SNL\node_modules\electron\dist\electron.exe
    goto ELECTRON_FOUND
)
if exist "%~dp0electron\dist\electron.exe" (
    set ELECTRON_EXE=%~dp0electron\dist\electron.exe
    goto ELECTRON_FOUND
)
for /f "delims=" %%i in ('where electron 2^>nul') do (
    if not defined ELECTRON_EXE set ELECTRON_EXE=%%i
)
if defined ELECTRON_EXE goto ELECTRON_FOUND

echo  Electron non detecte - mode Navigateur uniquement disponible.
echo.
goto CHECK_NODE

:ELECTRON_FOUND
echo  Electron : %ELECTRON_EXE%
echo.

:: ─────────────────────────────────────────────────────────────────────────────
::  Verifier Node.js
:: ─────────────────────────────────────────────────────────────────────────────
:CHECK_NODE
where node >nul 2>&1
if errorlevel 1 (
    echo  ERREUR : Node.js introuvable.
    echo  Telecharge et installe Node.js : https://nodejs.org
    echo.
    pause
    exit /b 1
)
echo  Node.js : OK
echo.

:: ─────────────────────────────────────────────────────────────────────────────
::  Menu principal
:: ─────────────────────────────────────────────────────────────────────────────
:MENU
echo  ============================================================
echo   MODE DE RECUPERATION
echo  ============================================================
echo.
if defined ELECTRON_EXE (
    echo   [1] Mode ELECTRON  ^(RECOMMANDE^)
    echo       Lit directement les donnees de l'app SNL installee
    echo.
    echo   [2] Mode NAVIGATEUR
    echo       Donnees ouvertes via Chrome ou Edge uniquement
    echo       ^(ne voit PAS les donnees de l'app installee^)
    echo.
    set /p CHOIX_MODE="  Ton choix [1 ou 2, Entree = 1] : "
    if "!CHOIX_MODE!"=="2" goto MODE_NODE_START
    goto CHOISIR_APP
) else (
    echo   Seul le mode Navigateur est disponible ^(Electron non trouve^).
    echo.
    set CHOIX_MODE=2
    goto MODE_NODE_START
)

:: ─────────────────────────────────────────────────────────────────────────────
::  Mode Electron : choisir le nom de l'app
:: ─────────────────────────────────────────────────────────────────────────────
:CHOISIR_APP
echo.
echo  ============================================================
echo   NOM DE L'APPLICATION
echo  ============================================================
echo.
echo   [1] No Limit Stock   ^(defaut^)
echo       %%APPDATA%%\No Limit Stock\...
echo.
echo   [2] Stock No Limit
echo       %%APPDATA%%\Stock No Limit\...
echo.
echo   [3] Autre nom
echo.
set /p CHOIX_APP="  Ton choix [1, 2 ou 3, Entree = 1] : "

if "!CHOIX_APP!"=="2" ( set APP_NAME=Stock No Limit & goto CHECK_USERDATA )
if "!CHOIX_APP!"=="3" (
    echo.
    set /p APP_NAME="  Nom exact de l'app (comme dans %%APPDATA%%) : "
    goto CHECK_USERDATA
)
set APP_NAME=No Limit Stock

:CHECK_USERDATA
set USERDATA=%APPDATA%\%APP_NAME%
echo.
if exist "!USERDATA!\" (
    echo  Dossier trouve : !USERDATA!
    goto MODE_ELECTRON_START
)
echo  ATTENTION : dossier introuvable : !USERDATA!
echo  Les donnees ne seront peut-etre pas accessibles.
echo.
set /p CONTINUER="  Continuer quand meme ? [o/n] : "
if /i "!CONTINUER!"=="n" goto MENU
goto MODE_ELECTRON_START

:: ─────────────────────────────────────────────────────────────────────────────
::  Fermeture de toute session existante sur le port 5173
:: ─────────────────────────────────────────────────────────────────────────────
:KILL_PORT
echo.
echo  Recherche d'une session active sur le port 5173...
curl -s -X POST http://localhost:5173/stop --max-time 2 >nul 2>&1
if not errorlevel 1 (
    echo  Session precedente arretee via /stop.
    ping 127.0.0.1 -n 3 >nul
)
netstat -ano 2>nul | findstr "0.0.0.0:5173 " | findstr "LISTENING" >nul 2>&1
if not errorlevel 1 goto DO_KILL
netstat -ano 2>nul | findstr "127.0.0.1:5173 " | findstr "LISTENING" >nul 2>&1
if not errorlevel 1 goto DO_KILL
goto PORT_READY

:DO_KILL
echo  Port 5173 encore occupe - arret du process...
for /f "tokens=5" %%a in ('netstat -ano 2^>nul ^| findstr ":5173 " ^| findstr "LISTENING"') do (
    taskkill /PID %%a /F >nul 2>&1
    echo  PID %%a termine.
)
ping 127.0.0.1 -n 3 >nul

:: Verifier une derniere fois
netstat -ano 2>nul | findstr ":5173 " | findstr "LISTENING" >nul 2>&1
if not errorlevel 1 (
    echo.
    echo  ATTENTION : port 5173 toujours occupe par un autre programme.
    echo.
    echo   [1] Quitter
    echo   [2] Continuer sur le port 5174
    echo.
    set /p CHOIX_PORT="  Ton choix [1 ou 2] : "
    if "!CHOIX_PORT!"=="1" ( pause & exit /b 0 )
    set PORT=5174
    goto PORT_READY
)

:PORT_READY
if not defined PORT set PORT=5173
goto :eof

:: ─────────────────────────────────────────────────────────────────────────────
::  DEMARRAGE MODE ELECTRON
:: ─────────────────────────────────────────────────────────────────────────────
:MODE_ELECTRON_START
set PORT=5173
call :KILL_PORT
echo.
echo  ============================================================
echo   Mode ELECTRON - app "!APP_NAME!" - port !PORT!
echo  ============================================================
echo.
echo  !! NE FERME PAS CETTE FENETRE pendant la recuperation !!
echo  !! Ferme-la uniquement quand tu as fini et exporte le JSON !!
echo.
echo  Lancement Electron...
"!ELECTRON_EXE!" "%~dp0electron-main.cjs" "!APP_NAME!" !PORT!
echo.
echo  Electron ferme.
pause
exit /b 0

:: ─────────────────────────────────────────────────────────────────────────────
::  DEMARRAGE MODE NODE (navigateur)
:: ─────────────────────────────────────────────────────────────────────────────
:MODE_NODE_START
set PORT=5173
call :KILL_PORT
echo.
echo  ============================================================
echo   Mode NAVIGATEUR - port !PORT!
echo  ============================================================
echo.
echo  !! NE FERME PAS CETTE FENETRE pendant la recuperation !!
echo  !! Ferme-la uniquement quand tu as fini et exporte le JSON !!
echo.
echo  Le navigateur va s'ouvrir automatiquement.
echo.
node "%~dp0serveur.cjs" !PORT! "No Limit Stock"
echo.
echo  Le serveur s'est arrete.
pause
exit /b 0
